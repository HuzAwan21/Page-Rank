#ifndef RANDOM_SURFER_H
#define RANDOM_SURFER_H

void simulate_random_surfer(Graph* graph, int num_steps, double p);

#endif
