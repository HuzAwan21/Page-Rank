#ifndef PRINTUSAGE_H
#define PRINTUSAGE_H

void print_usage();

#endif