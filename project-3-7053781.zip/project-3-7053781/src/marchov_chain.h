#ifndef MARCHOV_CHAIN_H
#define MARCHOV_CHAIN_H

#include "parse_input.h"

void simulate_markov_chain(Graph* graph, int num_steps, double p);

#endif
